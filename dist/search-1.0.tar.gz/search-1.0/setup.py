from setuptools import setup
setup(
    name='search',
    version='1.0',
    description='The Head First Python Search Tools',
    author='Timur Karimov',
    author_email='tumur.karimov@list.ru',
    url='headfirstlab.com',
    py_modules=['search'],
)
